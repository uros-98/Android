package com.example.packyourbag.Data;

import android.app.Application;
import android.content.Context;
import android.widget.Toast;

import com.example.packyourbag.Constants.MyConstatns;
import com.example.packyourbag.Database.RoomDB;
import com.example.packyourbag.Models.Items;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AppData extends Application {

    RoomDB database;
    Context context;

    public static final String LAST_VERSION = "LAST_VERSION";
    public static final int NEW_VERSION = 1;

    public AppData(RoomDB database) {
        this.database = database;
    }

    public AppData(RoomDB database, Context context) {
        this.database = database;
        this.context = context;
    }

    public List<Items> getBasicData() {
        String[] data = {"Wallte", "ID/Passport", "Cash", "Key"};
        return prepareItemsList(MyConstatns.BASIC_NEEDS_CAMEL_CASE, data);
    }

    public List<Items> getPersonalData() {
        String[] data = {"Toothbrush", "Toothpaste", "Soap/body wash", "Shampoo/conditioner", "Deoderant"};
        return prepareItemsList(MyConstatns.PERSONAL_CAMEL_CASE, data);
    }

    public List<Items> getClothingData() {
        String[] data = {"T-Shirt", "Jeans/pants", "Shorts", "Underwear", "Socks", "Shoes", "Pajamas", "Hat/cap"};
        return prepareItemsList(MyConstatns.CLOTHING_CAMEL_CASE, data);
    }

    public List<Items> getBabyNeedsData() {
        String[] data = {"Dapers", "Baby wipes", "Baby clothing", "Baby food/formula", "Bottles and sippy cups"};
        return prepareItemsList(MyConstatns.BABY_CAMEL_CASE, data);
    }

    public List<Items> getHealthData() {
        String[] data = {"Prescribed medications", "Pain relivers", "Band-aids", "Sunscreen", "Hand sanitzer"};
        return prepareItemsList(MyConstatns.HEALTH_CAMEL_CASE, data);
    }

    public List<Items> getTecnologyData() {
        String[] data = {"Lap top", "Phone", "Tablet", "Laptop charger", "Camera", "Phone charger", "SD Card"};
        return prepareItemsList(MyConstatns.TECHNOLOGY_CAMEL_CASE, data);
    }

    public List<Items> getFoodData() {
        String[] data = {"Snacks", "Granola bars", "Instant noodles", "Canned goods"};
        return prepareItemsList(MyConstatns.FOOD_CAMEL_CASE, data);
    }

    public List<Items> getBeachSuppliesData() {
        String[] data = {"Swimsuit", "Beack towel", "Sun hat", "Sunglasses", "Sunscreen", "Beach toys", "Beach bag"};
        return prepareItemsList(MyConstatns.BEACH_CAMEL_CASE, data);
    }

    public List<Items> getCarSuppliesData() {
        String[] data = {"Driver license", "Car keys", "GPS or map", "Emergency car kit", "First aid kit", "Car jack", "Motor oil", "Car tools"};
        return prepareItemsList(MyConstatns.CAR_SUPPLIES_CAMEL_CASE, data);
    }

    public List<Items> getNeedData() {
        String[] data = {"Wallet", "Tooth-paste", "Car key", "Band-aids"};
        return prepareItemsList(MyConstatns.NEEDS_CAMEL_CASE, data);
    }

    public List<Items> prepareItemsList(String category, String[] data) {
        List<String> list = Arrays.asList(data);
        List<Items> dataList = new ArrayList<>();

        for (int i = 0; i < list.size(); i++) {
            dataList.add(new Items(list.get(i), category, false));
        }
        return dataList;
    }

    public List<List<Items>> getAllData() {
        List<List<Items>> listOfAllItems = new ArrayList<>();

        listOfAllItems.add(getBasicData());
        listOfAllItems.add(getPersonalData());
        listOfAllItems.add(getHealthData());
        listOfAllItems.add(getFoodData());
        listOfAllItems.add(getBeachSuppliesData());
        listOfAllItems.add(getCarSuppliesData());
        listOfAllItems.add(getBabyNeedsData());
        listOfAllItems.add(getNeedData());
        listOfAllItems.add(getTecnologyData());
        listOfAllItems.add(getClothingData());

        return listOfAllItems;
    }

    public void persistDataByCategory(String category, boolean onlyDelete) {
        try {
            List<Items> list = deleteAndGetListCategory(category, onlyDelete);

            if (!onlyDelete) {
                for (Items items: list) {
                    database.mainDao().saveItems(items);
                }
                Toast.makeText(context, category + " Reset Successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, " Reset Successfully", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            Toast.makeText(context, "Something Went Wrong", Toast.LENGTH_SHORT).show();
        }
    }

    public void persistAllData() {
        List<List<Items>> listOfAllItems = getAllData();
        for (List<Items> list: listOfAllItems) {
            for (Items items: list) {
                database.mainDao().saveItems(items);
            }
        }
        System.out.printf("Data added");
    }

    private List<Items> deleteAndGetListCategory(String category, boolean onlyDelete) {
        if (onlyDelete) {
            database.mainDao().deleteAllByCategoryAndAddedBy(category, MyConstatns.SYSTEM_SMALL);
        } else {
            database.mainDao().deleteAllByCategory(category);
        }

        switch (category) {
            case MyConstatns.BASIC_NEEDS_CAMEL_CASE:
                return getBabyNeedsData();

            case MyConstatns.CLOTHING_CAMEL_CASE:
                return getClothingData();

            case MyConstatns.FOOD_CAMEL_CASE:
                return getFoodData();

            case MyConstatns.TECHNOLOGY_CAMEL_CASE:
                return getBabyNeedsData();

            case MyConstatns.BABY_CAMEL_CASE:
                return getBabyNeedsData();

            case MyConstatns.BEACH_CAMEL_CASE:
                return getBeachSuppliesData();

            case MyConstatns.PERSONAL_CAMEL_CASE:
                return getPersonalData();

            case MyConstatns.CAR_SUPPLIES_CAMEL_CASE:
                return getCarSuppliesData();

            case MyConstatns.HEALTH_CAMEL_CASE:
                return getHealthData();

            case MyConstatns.NEEDS_CAMEL_CASE:
                return getNeedData();

            default:
                return new ArrayList<>();
        }
    }
}
