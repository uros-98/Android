package com.example.packyourbag;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.packyourbag.Adapter.MyAdapter;
import com.example.packyourbag.Constants.MyConstatns;
import com.example.packyourbag.Data.AppData;
import com.example.packyourbag.Database.RoomDB;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final int TIME_INTERVAL = 2000;
    private long mBackPressed;
    private RecyclerView recyclerView;
    private List<String> titles;
    private List<Integer> images;
    private MyAdapter adapter;
    private RoomDB database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        recyclerView = findViewById(R.id.recyclerView);
        if (recyclerView == null) {
            throw new NullPointerException("RecyclerView not found in layout. Check activity_main.xml");
        }

        database = RoomDB.getInstance(this);
        addAllTitles();
        addAllImages();
        persistAppData();

        setupRecyclerView();
    }

    private void setupRecyclerView() {
        adapter = new MyAdapter(this, titles, images, this);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2);
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.setAdapter(adapter);
    }

    private void persistAppData() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = prefs.edit();
        AppData appData = new AppData(database);

        int lastVersion = prefs.getInt(AppData.LAST_VERSION, 0);
        boolean isFirstTime = prefs.getBoolean(MyConstatns.FIRST_TIME_CAMEL_CASE, false);

        if (!isFirstTime) {
            appData.persistAllData();
            editor.putBoolean(MyConstatns.FIRST_TIME_CAMEL_CASE, true);
        } else if (lastVersion < AppData.NEW_VERSION) {
            database.mainDao().deleteAllSystemItems(MyConstatns.SYSTEM_SMALL);
            appData.persistAllData();
            editor.putInt(AppData.LAST_VERSION, AppData.NEW_VERSION);
        }
        editor.apply();
    }

    @Override
    public void onBackPressed() {
        if (mBackPressed + TIME_INTERVAL > System.currentTimeMillis()) {
            super.onBackPressed();
        } else {
            Toast.makeText(this, "Tap back button again to exit", Toast.LENGTH_SHORT).show();
            mBackPressed = System.currentTimeMillis();
        }
    }

    private void addAllImages() {
        images = new ArrayList<>();
        images.add(R.drawable.basic_needs);
        images.add(R.drawable.cloths);
        images.add(R.drawable.person_care);
        images.add(R.drawable.baby_needs);
        images.add(R.drawable.health);
        images.add(R.drawable.technology);
        images.add(R.drawable.food);
        images.add(R.drawable.beach);
        images.add(R.drawable.car);
        images.add(R.drawable.need);
        images.add(R.drawable.mylist);
        images.add(R.drawable.selection);
    }

    private void addAllTitles() {
        titles = new ArrayList<>();
        titles.add(MyConstatns.BASIC_NEEDS_CAMEL_CASE);
        titles.add(MyConstatns.CLOTHING_CAMEL_CASE);
        titles.add(MyConstatns.PERSONAL_CAMEL_CASE);
        titles.add(MyConstatns.BABY_CAMEL_CASE);
        titles.add(MyConstatns.HEALTH_CAMEL_CASE);
        titles.add(MyConstatns.TECHNOLOGY_CAMEL_CASE);
        titles.add(MyConstatns.FOOD_CAMEL_CASE);
        titles.add(MyConstatns.BEACH_CAMEL_CASE);
        titles.add(MyConstatns.CAR_SUPPLIES_CAMEL_CASE);
        titles.add(MyConstatns.NEEDS_CAMEL_CASE);
        titles.add(MyConstatns.MY_LIST_CAMEL_CASE);
        titles.add(MyConstatns.MY_SELECTIONS_CAMEL_CASE);
    }
}
